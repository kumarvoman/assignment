#pragma once
#include <fstream>
#include <sstream>
#include <string>
#include <queue>
#include <random>
#include <iomanip>
#include "EnglishPremierLeague.h"
using namespace std;

std::random_device rd;
std::mt19937 generator(rd()); // Standard mersenne_twister_engine seeded with rd()
std::uniform_real_distribution<double> distribute(0.0, 1.0);

/**************************************************************************************
function name:readMeanGoals
return type: void
parameters:
behaviour: read the given csv file and update the data into meangoals structure.
**************************************************************************************/
const void EnglishPremierLeague::readMeanGoals(const string filename)
{
    try
    {
        std::ifstream _inputfile(filename);
        std::string line;
        std::getline(_inputfile, line);
        while (std::getline(_inputfile, line))
        {
            cout << line << endl;
            auto pos = line.find(',');
            line[pos] = ' ';
            string clubname = "";
            double goals = 0.0;

            std::stringstream ss;
            ss << line;
            while (ss >> clubname >> goals)
            {
                this->meangoals.push_back({ clubname, goals });
                this->teams.push_back(clubname);
            }
        }
        _inputfile.close();
    }
    catch (exception ex)
    {
        cout << "Error: " << ex.what() << endl;
    }
}

/**************************************************************************************
function name:getMeanGoals
return type: vector<club_MeanGoals>
parameters:
behaviour:
    return the meangolas structure from current season
**************************************************************************************/
const vector<club_MeanGoals> EnglishPremierLeague::getMeanGoals()
{
    return this->meangoals;
}

/**************************************************************************************
function name:GetGoalDistribution
return type: map<uint32_t, double>
parameters:
            double meanGoalPerMatch : Given mean value from csv file
behaviour:
    return the distributions for current club based on mean goal.
**************************************************************************************/

const std::map<uint32_t, double> EnglishPremierLeague::GetGoalDistribution(const double meanGoalPerMatch)
{
    //constexpr auto lbdFactorial{ [](const uint32_t factorial) {
    const auto lbdFactorial{ [](const uint32_t factorial) {
        auto result{ 1u };
        for (uint32_t idx = 1u; idx <= factorial; ++idx)
        {
            result *= idx;
        }
        return result;
    } };

    constexpr auto maxGoals{ 5u };

    auto prevProbability{ 0.0 };
    std::map<uint32_t, double> goalDist;
    for (uint32_t i = 0u; i < maxGoals; ++i)
    {
        const auto probPoisson{ (std::pow(meanGoalPerMatch, i) * std::exp(-1 * meanGoalPerMatch))
                    / lbdFactorial(i) };

        goalDist.emplace(std::make_pair(i, (probPoisson + prevProbability)));
        prevProbability += probPoisson;
    }

    goalDist.emplace(std::make_pair(maxGoals, 1.0));

    return goalDist;
}

/**************************************************************************************
function name:assingDistribution
return type: void
parameters:
           string club : clubname
           map<uint32_t, double> dist : distribution for the current club
behaviour:
    assign the distributions with given club.
**************************************************************************************/
const void EnglishPremierLeague::assingDistribution(string club, map<uint32_t, double> dist)
{
    this->distribution[club] = dist;
}

/**************************************************************************************
function name:getGoalCount
return type: uint32_t
parameters:
            random->random no to compare with and give goal count
            name-> name of the club to get the distributions
behaviour:
    return no of goals from 0-5, based on comparison of random and distributions
**************************************************************************************/
const uint32_t EnglishPremierLeague::getGoalCount(const double random, const string name)
{
    uint32_t goalsScored = 0;
    auto x = this->distribution[name];
   
    if (random < x[0])
        goalsScored = 0;
    else if (random < x[1])
        goalsScored = 1;
    else if (random < x[2])
        goalsScored = 2;
    else if (random < x[3])
        goalsScored = 3;
    else if (random < x[4])
        goalsScored = 4;
    else
        goalsScored = 5;
    return goalsScored;
}


/**************************************************************************************
function name:start
return type: void
parameters:
behaviour:
    this function will run the actual matches,
    one team gets to play 2 matches against every other team.
    and based on the match result will update the scoreboard.
**************************************************************************************/
const void EnglishPremierLeague::start()
{
    try
    {
        queue<pair<string, string>> matches; //this is not getting used as of now
        int clubscount = static_cast<int>(teams.size());
        for (int i = 0; i < clubscount; i++)
        {
            clubInfo* teamA = new clubInfo();
            if (this->matchStats.find(teams[i]) != this->matchStats.end())
                teamA = this->matchStats[teams[i]];
            teamA->Club = teams[i];
            for (int j = 0; j < clubscount; j++)
            {
                if (j == i)
                    continue;
                matches.push(make_pair(teams[i], teams[j])); //this is not getting used as of now

                clubInfo* teamB = new clubInfo();
                if (this->matchStats.find(teams[j]) != this->matchStats.end())
                    teamB = this->matchStats[teams[j]];
                teamB->Club = teams[j];

                double ranA = distribute(generator);
                double ranB = distribute(generator);

                int countB = getGoalCount(ranB, teamB->Club);
                int countA = getGoalCount(ranA, teamA->Club);
                teamB->goalScored += countB;
                teamA->goalConceded += countB;
                teamA->goalScored += countA;
                teamB->goalConceded += countA;
                if (countA > countB)
                {
                    teamA->won++;
                    teamB->lost++;
                    teamA->points += result::won;
                    teamB->points += result::lost;
                }
                else if (countA < countB)
                {
                    teamB->won++;
                    teamA->lost++;
                    teamB->points += result::won;
                    teamA->points += result::lost;
                }
                else
                {
                    teamA->drawn++;
                    teamB->drawn++;
                    teamA->points += result::draw;
                    teamB->points += result::draw;
                }
                teamA->played++;
                teamB->played++;
                this->matchStats[teamA->Club] = teamA;
                this->matchStats[teamB->Club] = teamB;
            }
        }
    }
    catch (exception ex)
    {
        std::cout << "Error: " << ex.what() << endl;
    }
}


/**************************************************************************************
function name:printScoreboard
return type: void
parameters:
behaviour:
    will print the scoreboard on the console.
**************************************************************************************/
const void EnglishPremierLeague::printScoreboard()
{
    //preparing scoreboard
    for (auto x : matchStats)
    {
        this->scoreBoard.push_back({ x.second->points, x.second });
    }

    std::sort(this->scoreBoard.begin(), this->scoreBoard.end());

    int count = 1;
    int n = static_cast<int>(this->scoreBoard.size() - 1);
    for (int i = n;i>=0;i--)
    {
        if (i == n)
             cout << right << setw(' ') << setw(30)<< "Positon \tClub \tPlayed \tWon \tLost \tDraw \tGS \tGC \tPoints" << endl;
        auto x = this->scoreBoard[i];
        cout << count++ << "\t";
        cout <<  setw(10) << x.second->Club << "\t" <<
            x.second->played << "\t" <<
            x.second->won << "\t" <<
            x.second->lost << "\t" <<
            x.second->drawn << "\t" <<
            x.second->goalScored << "\t" <<
            x.second->goalConceded << "\t" <<
            x.second->points << endl;
    }
}

const void EnglishPremierLeague::printCSV()
{
    try
    {
        std::ofstream scoretable;
        scoretable.open("English_Premier_League_ScoreBoard.csv");

        int count = 1;
        int n = static_cast<int>(this->scoreBoard.size() - 1);
        for (int i = n; i >= 0; i--)
        {
            if (i == n)
                scoretable << right << setw(' ') << setw(30) << "Positon,Club,Played,Won,Lost,Draw,Goals Scored,Goals Conceded,Points" << endl;

            auto x = this->scoreBoard[i];
            scoretable << count++ << "," <<
                x.second->Club << "," <<
                x.second->played << "," <<
                x.second->won << "," <<
                x.second->lost << "," <<
                x.second->drawn << "," <<
                x.second->goalScored << "," <<
                x.second->goalConceded << "," <<
                x.second->points << endl;
        }
        scoretable.close();
    }
    catch (exception ex)
    {
        std::cout << "Error: " << ex.what() << endl;
    }
}