#pragma once
#ifndef ENGLISH_PREMIER_LEAGUE_H_
#define ENGLISH_PREMIER_LEAGUE_H_
#include <iostream>
#include <map>
#include <vector>
#include "Football_Tournament.h"

using namespace std;

class EnglishPremierLeague {
    vector<string> teams;
    vector<club_MeanGoals> meangoals;
    vector<pair<int, clubInfo*>> scoreBoard;
    map<string, clubInfo*> matchStats;    
    map<string, map<uint32_t, double>> distribution;
public:
    const void start();
    const void printScoreboard();
    const void readMeanGoals(const string filename);
    const void assingDistribution(string name, map<uint32_t, double> dist);
    const vector<club_MeanGoals> getMeanGoals();
    const std::map<uint32_t, double> GetGoalDistribution(const double meanGoalPerMatch);
    const uint32_t getGoalCount(const double random, const string name);  
    const void printCSV();
};
#endif