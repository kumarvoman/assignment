﻿// Football_Tournament.cpp : Defines the entry point for the application.
//
// Standard headers.
#include <iostream>
#include <memory>
#include "EnglishPremierLeague.h"

using namespace std;

int main()
{
    try
    {
        string filename = "";
        std::cout << "Enter the full name for csv file: ";
        std::cin >> filename;
        std::unique_ptr<EnglishPremierLeague> league(new EnglishPremierLeague());

        league->readMeanGoals(filename); //reading the given csv file
        std::cout << "Tournament Started" << endl;
        std::cout << "--------------------------------------------------" << endl;
        const auto _means = league->getMeanGoals();
        for each (auto currmean in _means)
        {
            auto dist = league->GetGoalDistribution(currmean.meanGoals);
            league->assingDistribution(currmean.clubname, dist);
        }//distributions for each team has been calculated

        //start the matches
        league->start();

        //print scoreboard
        league->printScoreboard();

        //generate csv scoreboard
        league->printCSV();
        std::cout << "--------------------------------------------------" << endl;
        std::cout << "Tournamnet over" << endl;
    }
    catch (exception ex)
    {
        std::cout << "Error: " << ex.what() << endl;
    }
	return 0;
}



