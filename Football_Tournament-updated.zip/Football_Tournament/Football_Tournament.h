﻿// Football_Tournament.h : Include file for standard system include files,
// or project specific include files.

#pragma once
#ifndef FOOTBALL_TOURNAMENT_H_
#define FOOTBALL_TOURNAMENT_H_
#include <iostream>
using namespace std;

enum result
{
    lost = 0,
    draw = 1,
    won = 3
};

struct clubInfo {
    uint32_t position;
    uint32_t played;
    uint32_t won;
    uint32_t drawn;
    uint32_t lost;
    uint32_t goalScored;
    uint32_t goalConceded;
    uint32_t points;
    string Club;
    
    clubInfo()
    {
        position = 0;
        played = 0;
        won = 0;
        drawn = 0;
        lost = 0;
        goalScored = 0;
        goalConceded = 0;
        points = 0;
        Club = "";
    }
};

struct club_MeanGoals {
    string clubname;
    double meanGoals;
};

#endif

